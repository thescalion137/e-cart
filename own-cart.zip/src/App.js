import { BrowserRouter as Router, Switch, Route, Routes } from "react-router-dom";
import logo from "./logo.svg";
import "./App.css";
import "./styles/globals.css";
import Home from "./pages/Home";
import Cart from "./pages/Cart";
import Product from "./pages/Product";

function App() {
  return (
    <>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/:productId" element={<Product />} />

          {/* <Route path="/:brand">
            <Brand />
          </Route> */}
          <Route path="/test" element={<div>test</div>} />
        </Routes>
      </Router>
    </>
  );
}

export default App;
