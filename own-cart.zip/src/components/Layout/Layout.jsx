import Nav from '../Nav';
import Footer from '../Footer';

import './Layout.module.css';

const Layout = ({ children }) => {
  return (
    <div className='layout'>
      <Nav />
      { children }
      <Footer />
    </div>
  )
}

export default Layout;