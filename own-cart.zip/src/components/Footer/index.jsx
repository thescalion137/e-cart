


export { default } from './Footer';