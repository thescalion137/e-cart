import React from 'react'
import { useParams } from 'react-router-dom';
import Layout from '../../components/Layout';
import Container from '../../components/Container';
import styles from "../../styles/Product.module.css"

const product =  {
    "title": "Snipcart Logo Sticker Pack",
    "id": "sticker_logo_pack",
    "description": "Get a pack of 3 Snipcart logo stickers.",
    "price": "4.00",
    "image": "/images/sticker-3pack.jpg"
  }

const Product = () => {
    const { productId } = useParams();
    console.log("🚀 ~ file: index.jsx:6 ~ Product ~ productId:", productId)

  return (
    <Layout>
      {/* <Head>
        <title>{product.title} - Snipcart Store</title>
      </Head> */}
      <Container>
        <div className={styles.product}>
          <div className={styles.productImage}>
            <img src={product.image} alt={`Preview of ${product.title}`} />
          </div>

          <div className={styles.productDetails}>
            <h1>{product.title}</h1>

            <p>{product.description}</p>

            <p>${product.price}</p>

            <p>
              <button
                className="snipcart-add-item"
                data-item-id={product.id}
                data-item-image={product.image}
                data-item-name={product.title}
                data-item-url={`/products/${product.id}`}
                data-item-price={product.price}
              >
                Add to Cart
              </button>
            </p>
          </div>
        </div>
      </Container>
    </Layout>
  );
}

export default Product