// import products from "../../../products.json";
import { useNavigate, useNavigation } from "react-router-dom";
import { FaShoppingCart } from "react-icons/fa";
import { BiArrowBack } from "react-icons/bi";
import Container from "../../components/Container";
import Layout from "../../components/Layout";
import styles from "../../styles/Home.module.css";
import { useState } from "react";
import Drawer from "react-modern-drawer";
import "react-modern-drawer/dist/index.css";
import "./styles.css";

const products = [
  {
    title: "Snipcart Logo Sticker",
    id: "sticker_logo",
    description: "Show off your Snipcart support with a logo sticker!",
    price: "2.00",
    image: "/images/sticker-single.jpg",
  },
  {
    title: "Snipcart Logo Sticker Pack",
    id: "sticker_logo_pack",
    description: "Get a pack of 3 Snipcart logo stickers.",
    price: "4.00",
    image: "/images/sticker-3pack.jpg",
  },
];

export default function Home() {
  const [isOpen, setIsOpen] = useState(false);
  const toggleDrawer = () => {
    setIsOpen((prevState) => !prevState);
  };

  const navigate = useNavigate();
  return (
    <Layout>
      {/* <div>
        <div>Snipcart Store</div>
      </div> */}
      <Container className={styles.homeContainer}>
        <div className={styles.grid}>
          {products.map((product) => {
            return (
              <div key={product.id} className={styles.card}>
                <div
                  onClick={() => navigate(`${product.id}`)}
                  style={{ cursor: "pointer" }}
                >
                  <div>
                    <img
                      src={product.image}
                      alt={`Preview of ${product.title}`}
                    />
                    <h3>{product.title}</h3>
                    <p className={styles.cardDescription}>
                      {product.description}
                    </p>
                    <p>${product.price}</p>
                  </div>
                </div>
                <p>
                  <button
                    className="snipcart-add-item"
                    data-item-id={product.id}
                    data-item-image={product.image}
                    data-item-name={product.title}
                    data-item-price={product.price}
                  >
                    Add to Cart
                  </button>
                </p>
              </div>
            );
          })}
        </div>
      </Container>

      <button onClick={toggleDrawer}>Show</button>

      <Drawer
        open={isOpen}
        onClose={toggleDrawer}
        direction="right"
        className="bla bla bla"
        size="100%"
      >
        <div
          style={{ backgroundColor: "#f1f2f4", width: "100%", height: "100%" }}
        >
          <div
            className="header"
            style={{
              display: "flex",
              justifyContent: "space-between",
              padding: "20px 15%",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "10px",
                cursor: "pointer",
                fontSize: "14px",
              }}
              onClick={() => toggleDrawer()}
            >
              <BiArrowBack /> <span>Continue shopping</span>
            </div>
            <div style={{ fontWeight: "600" }}>Cart Summery</div>
            <div>
              <FaShoppingCart />
            </div>
          </div>
          <div className="content">
            <div class="CartContainer">
              <div class="Header">
                <h3 class="Heading">Shopping Cart</h3>
                <h5 class="Action">Remove all</h5>
              </div>

              <div class="Cart-Items">
                <div class="image-box">
                  <img src="images/apple.png" style={{ height: "120px" }} />
                </div>
                <div class="about">
                  <h1 class="title">Apple Juice</h1>
                  <h3 class="subtitle">250ml</h3>
                  <img src="images/veg.png" style={{ height: "30px" }} />
                </div>
                {/* <div class="counter">
                  <div class="btn">+</div>
                  <div class="count">2</div>
                  <div class="btn">-</div>
                </div> */}
                <div class="prices">
                  <div class="amount">$2.99</div>
                  <div class="save">
                    <u>Save for later</u>
                  </div>
                  <div class="remove">
                    <u>Remove</u>
                  </div>
                </div>
              </div>

              <div class="Cart-Items pad">
                <div class="image-box">
                  <img src="images/grapes.png" style={{ height: "120px" }} />
                </div>
                <div class="about">
                  <h1 class="title">Grapes Juice</h1>
                  <h3 class="subtitle">250ml</h3>
                  <img src="images/veg.png" style={{ height: "30px" }} />
                </div>
                <div class="counter">
                  <div class="btn">+</div>
                  <div class="count">1</div>
                  <div class="btn">-</div>
                </div>
                <div class="prices">
                  <div class="amount">$3.19</div>
                  <div class="save">
                    <u>Save for later</u>
                  </div>
                  <div class="remove">
                    <u>Remove</u>
                  </div>
                </div>
              </div>
              <hr />
              <div class="checkout">
                <div class="total">
                  <div>
                    <div class="Subtotal">Sub-Total</div>
                    <div class="items">2 items</div>
                  </div>
                  <div class="total-amount">$6.18</div>
                </div>
                <button class="button">Checkout</button>
              </div>
            </div>
          </div>
        </div>
      </Drawer>
    </Layout>
  );
}
